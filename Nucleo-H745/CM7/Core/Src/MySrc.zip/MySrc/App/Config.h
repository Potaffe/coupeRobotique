
#ifndef __CONFIG__
#define __CONFIG__

#include <stdint.h>
#include "tim.h"
#include "usart.h"
#include "main.h"
#include "../../../Common/Src/gpio.h"

#define FCY 240000000UL

#define DEF_SYM_AUTO 1  ////Utilisation du symétriseur automatique ou non

#define huartCom huart4
#define huartRX huart2
#define huartAX huart5
#define huartAff huart6

#define htimPWM htim1
#define htimAss htim8
#define htimMs htim13
#define htimADC htim6
#define htimCodX htim2
#define htimCodG htim3
#define htimCodD htim4

#define hadc hadc3

#define VAL_COUL_POS C565_Yellow
#define VAL_COUL_NEG C565_Magenta

enum {COUL_POS,COUL_NEG};

#define COULEUR_DEF COUL_POS


extern volatile int SYM_AUTO;  //Utilisation du symétriseur automatique ou non
extern volatile uint16_t VBAT;

#define INV_COD1 1 //Gauche
#define INV_COD2 0 //Droite
#define INV_CODX 0 //X

//D�finition timers utilis�s pour codeurs
#define POS1CNT (INV_COD1? (-__HAL_TIM_GetCounter(&htimCodG)):__HAL_TIM_GetCounter(&htimCodG)) //Gauche
#define POS2CNT (INV_COD2? (-__HAL_TIM_GetCounter(&htimCodD)):__HAL_TIM_GetCounter(&htimCodD)) //Droite
#define POSXCNT (INV_CODX? (-__HAL_TIM_GetCounter(&htimCodX)):__HAL_TIM_GetCounter(&htimCodX)) //X


#define FPWM 20000

#define PWMG ((&htimPWM)->Instance->CCR1)
#define PWMD ((&htimPWM)->Instance->CCR2)
#define PWMX ((&htimPWM)->Instance->CCR3)
#define PWMmin 0
#define PWMmax ((uint16_t)(FCY/FPWM))   //216MHz/20kHz

#define INV_MOTG 0
#define INV_MOTD 1
#define INV_MOTX 0
#define VREF 13500




#define __Pin(x,st) HAL_GPIO_WritePin(x##_GPIO_Port, x##_Pin, (st)?GPIO_PIN_SET:GPIO_PIN_RESET)
#define __InvPin(x,st) HAL_GPIO_WritePin(x##_GPIO_Port, x##_Pin, (st)?GPIO_PIN_RESET:GPIO_PIN_SET)

#define __StPin(x) HAL_GPIO_ReadPin(x##_GPIO_Port,x##_Pin)

#define _LEDV(st) __Pin(LEDV,st)
#define _LEDJ(st) __Pin(LEDJ,st)
#define _LEDR(st) __Pin(LEDR,st)




//Attention : "commandes" parfois inversées !
//#define _Powen(st) HAL_GPIO_WritePin(POWEN_GPIO_Port, POWEN_Pin, (st)?GPIO_PIN_SET:GPIO_PIN_RESET)
#define _Powen(st) __Pin(POWEN,st)
//#define _PowTurbine(st) HAL_GPIO_WritePin(EN_TURBINE_GPIO_Port, EN_TURBINE_Pin, (st)?GPIO_PIN_SET:GPIO_PIN_RESET)

#define _PowTurbine(st) __Pin(EN_TURB,st)
#define _PowenX(st) __Pin(POWENX,st)
#define _PowPompe(st) __InvPin(PowPompe,st)
#define _PompeA(st) __InvPin(PompeA,st)
#define _PompeB(st) __InvPin(PompeB,st)

#define _ServoRX_RW(st) __Pin(ServoRX_RW,st)
#define _ServoAX_RW(st) __Pin(ServoAX_RW,st)


#define _Tirette __StPin(TIRETTE)
#define _TopX __StPin(TopX)

#define _BP __StPin(BUTTON)

#define _CAPTUS __StPin(CAPTUS)


#define EnableAsserv(en) ((en)? __HAL_TIM_ENABLE_IT(&htimAss, TIM_IT_UPDATE): __HAL_TIM_DISABLE_IT(&htimAss, TIM_IT_UPDATE))


#define I2C_AD_US 0x51
#define I2CAD_COUL 0x34


void USStop(void);
void USAV(void);
void USAR(void);
void USCouleur(uint16_t col);


#endif

