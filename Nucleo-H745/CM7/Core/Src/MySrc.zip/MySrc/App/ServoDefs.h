/*
 * ServoDefs.h
 *
 *  Created on: 24 nov. 2016
 *      Author: Md
 */

#ifndef SERVODEFS_H_
#define SERVODEFS_H_


#define SV_MAIN RXID(22)
#define SV_BRAS RXID(24)
#define SV_EPAULE RXID(45)




#endif /* SERVODEFS_H_ */
