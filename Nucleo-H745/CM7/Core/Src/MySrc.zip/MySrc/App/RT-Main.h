/*
 * RT-Main.h
 *
 *  Created on: 19 ao�t 2017
 *      Author: Md
 */

#ifndef RT_MAIN_H_
#define RT_MAIN_H_

void RT_Main(void *pvParameters);

void USStop(void);
void USAV(void);
void USAR(void);
void USAVAR(void);
void USAlt(uint16_t mode);
void USCouleur(uint16_t col);


extern volatile unsigned CT_ADC,ERR_ADC;
extern TaskHandle_t hMain;

#endif /* RT_MAIN_H_ */
