/*
 * Menu.h
 *
 *  Created on: 6 mars 2017
 *      Author: Md
 */

#ifndef MENU_H_
#define MENU_H_


extern uint16_t COULEUR;


void (*Menu(void))(void);


#endif /* MENU_H_ */
