/*
 * CaptCol.h
 *
 *  Created on: 21 oct. 2019
 *      Author: deloi
 */

#ifndef CAPTCOL_H_
#define CAPTCOL_H_
#include <stdint.h>

void CCLeds(int on);
void CCCouleur(uint16_t col);
void CCPosServo(uint8_t n, uint16_t pos);
int16_t CCGetCol(unsigned capt);
const char *StrCol(uint16_t c);

enum {CC_Rouge,CC_Bleu,CC_Vert,CC_Blanc,CC_Jaune,CC_Violet,CC_Cyan};

#endif /* CAPTCOL_H_ */
