#ifndef __ASSERV_H__
#define __ASSERV_H__


#ifndef PI
#define  PI 3.1415926535897932384626433832795f
#endif
////////////////// Param�tres odom�trie////////////////////////////// 

#define TOPSCODEUR_ROUE_LIBRE 4096 // Tops/tour 1024*4
#define DIAM_ROUE_LIBRE  (50.045f)	// Diminuer pour augmenter la distance parcourue
// �cart entre roues pour Commande (augmenter si angle trop faible)
#define INTER_ROUE_LIBREC 254.8f   //Gros robot
//#define INTER_ROUE_LIBREC 335.5f // Robot d�mo
#define KDISSYM 1.0f //Coef. d'ajustement correction odom�trie (augmenter si angle odo trop grand)


extern volatile int SYM_AUTO;  //Utilisation du sym�triseur automatique ou non


//Constantes � ne pas modifier !
#define INTER_ROUE_LIBRE (INTER_ROUE_LIBREC*KDISSYM)
#define KDIM ((float)(PI*DIAM_ROUE_LIBRE/TOPSCODEUR_ROUE_LIBRE))   //mm par top
#define D_COD(mm) ((float)((mm)/KDIM)) // dist.en mm convertie en tops codeur

#define MULPREC 1024

//#define _ConvAnglelpp (PI*INTER_ROUE_LIBREC/KDIM*MULPREC/3600.f)
#define _ConvAnglelpp(x) ((float)(x)*(INTER_ROUE_LIBREC/3600.f/DIAM_ROUE_LIBRE*MULPREC*TOPSCODEUR_ROUE_LIBRE))
#define _ConvDistlpp(x) ((float)(x)*(MULPREC/KDIM))


/////////////////////////////////////////////////////////////////////////


#define FPWM   20000     //Fr�quence de hachage

//#define ValPTPER ((int)((FCY/FPWM)-1)) //Valeur pour assurer une MLI
                         //FPWM de rapport cyclique 0.5 ValPTPER=1500
//#define Garde 2	//limite en % le rapport cyclique
//#define PWMz ValPTPER


long GetPosG(void);
long GetPosD(void);
void TryToSyncSPI(void);
void GestAsserv(void);

void SetPrmX(float vmax, float acc);
void StartX(int pos);  //Lance le mouvement sur le moteur X vers la position pos
int XIsRunning(void);  //Indique si le moteur X est en train de tourner
void MoveX(int pos);  //Bouge le moteur X jusqu'� la position indiqu�e. Attend la fin du mouvement.
int GetPosMotX(void); //Renvoie la position codeur du moteur X
void StopMotX(void);



#include <stdint.h>
extern volatile uint16_t VBAT;

#endif
