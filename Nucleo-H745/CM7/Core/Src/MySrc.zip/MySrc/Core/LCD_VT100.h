/* Gestion terminal vt100 sur RS232C

Codes de caractères spéciaux :
	'\t' : Efface la fin de ligne
	'\r' : Retour en début de ligne
	'\n' : Descend le curseur à la ligne en dessous (même colonne)
	0x08 : Efface le caractère avant le curseur et recule le curseur
	0x90 : alpha
	0x91 : beta
	0x92 : epsilon
	0x93 : sigma
	0x94 : rau
	0x95 : teta
	0x96 : infini
	0x97 : omega
	0x98 : SIGMA
	0x99 : pi
	0x9A : µ
*/

#ifndef __TERM_VT100_H__
#define __TERM_VT100_H__
#include <stdint.h>
#include "cmsis_os.h"
//#include "task.h"


#include "ColorDefs.h"

#define VT100 1
#define LCD 0

#define STD_UART_AFF 1
void HuartAff_RxCpltCallback(void);
void HuartAff_TxCpltCallback(void);
void HuartAff_ErrorCallback(void);


/* lcdinit : Fonction d'initialisation.
   Doit être appelée avant toute autre fonction.
   Sortie sur afficheur LCD si prf=0
   Sortie sur VT100 si prf=1
 */
void lcdinit(int prf);

// autorisation (si != 0) ou interdiction (si = 0) des caractères de contrôle pour sortie VT100
// peut être appelée avant lcdinit().
void VTCtrl(int s);

// lcdputc : Ecriture d'un caractère
void lcdputc(unsigned char x);

// lcdgotoxy : Positionne le curseur à la ligne y (1...4) et colonne x (1...20)
void lcdgotoxy(unsigned char x, unsigned char y);

// renvoie le numéro de la colonne courante (1...20)
unsigned lcdgetx(void);

// renvoie le numéro de la ligne courante (1...4)
unsigned lcdgety(void);

// sauvegarde la position courante du curseur et positionne le curseur en x,y
// renvoie 0 si pas de sauvegarde possible (ne modifie pas la position dans ce cas). Renvoie 1 si Ok.
int lcdpushxy(unsigned char x, unsigned char y);

// Replace le curseur à la dernière position sauvegardée par lcdpusxy()
// renvoie 0 si pas de sauvegarde ou 1 si Ok.
int lcdpopxy(void);


// lcdputs : Ecriture d'une cha�ne de caract�res
void lcdputs(const char *str);

// lcdclrscr : Efface l'écran (curseur revient à l'origine)
void lcdclrscr(void);

// lcdclreol : Efface la fin de la ligne, à partir de la position du curseur
void lcdclreol(void);

// lcdhome : Ramène le curseur à l'origine (Ligne 1, Colonne 1)
void lcdhome(void);

/* lcdcursor : Définit le curseur :
   curs=0 : pas de curseur
   curs=1 : souligné
   curs=2 : clignotant */
void lcdcursor(unsigned char curs);

/* lcdprint : Fonction printf modifiée
Quasi identique à printf avec les formats suivants :
%% : affiche '%'
%c : affiche un caractère
%[.c]s : affiche une chaîne de caractères (c caractères maxi)
%[n][l]u : affiche un entier non signé
%[n][l]x : affiche un entier non signé en hexad�cimal
%[n][l]b : affiche un entier non signé en binaire
%[n][l]d : affiche un entier signé
%[n][.c][*m]U : affiche le résultat de l'entier non signé divisé par m
%[n][.c][*m]D : affiche le résultat de l'entier signé divisé par m
[n] : affichage avec n chiffres
[l] : pour un entier long
[.c] : avec c chiffres derrière la virgule
Exemples : 
   lcdprintf("Résultat : %5.1*8D\t\r",x);
      Affiche la valeur de (x/8) sur 5 chiffres, avec 1 chiffre après la virgule
      Efface le reste de la ligne et revient en début de ligne
   lcdprintf("N=%u%u%u%.3s\r\n",c,d,u,unit);
      Affiche "N=" et les valeurs de c, d et u, puis la chaîne unit avec 3 car. maxi.
      Passe ensuite au début de la ligne suivante.
*/
void lcdprintf(const char *fmt,...);

// GetChar : Lecture du clavier de la console VT100
// Renvoie le code du caractère reçu ou -1 si rien
int16_t GetChar(void);
int16_t GetCharTimeOut(uint16_t ms);

//Transfert des caractères de sortie affichage vers la fonction fct
//si fct=0 : sortie affichage normal
void lcdFout(void (*fct)(unsigned char));


//Accès possible aux fonctions étendues :
void VTExtended(uint16_t e);


//Fonctions étendues (pour afficheur tactile)

//S�lection couleur d'écriture :
void lcdTextColor565(uint16_t c);
void lcdTextColor(uint32_t c);

//Sélection couleur de fond :
void lcdBackColor565(uint16_t c);
void lcdBackColor(uint32_t c);

//Sélection de la police :
//Polices disponibles : (avec xx=10,12,14,16,18,22,24,28,48)
// Arialxx, Calibrixx, ComicSansMsxx, CourierNewxx, Deliusxx, Consolasxx
//Largeur fixe si 1er caractère en majuscule.
void lcdSetFont(const char *nf);

//Sélectionne la police N° NumFont de taille Size (valeur la plus proche)
//Si NumFont est invalide, ne fait rien (NumFont=0...lcdGetNbFont()-1)
//0:Arial, 1:Calibri, 2:ComicSansMs, 3:CourierNew, 4:Consolas, 5:Delius
//40 à 45 pour largeur fixe
void lcdSetFontN(uint16_t NumFont, uint16_t Size);


//Définition d'une zone tactile sur l'écran
// (x,y) : coordonnées du coin supérieur gauche de la zone dans le LCD
// mul : coef d'agrandissement en hauteur pour la zone tactile en % (Ex : mul=150 -> h*1,5)
// txt : texte à écrire (utilisation des couleurs courantes
// col565 : couleur du cadre entourant la zone
// id : identifiant de la zone à créer (ou à modifier) de 0 à 15
//Quand une zone est créée, l'appui sur la zone renvoie le code ('A'+id) (à lire avec GetChar)
void lcdDefTouch(int16_t x, int16_t y, uint16_t mul, const char *txt, uint16_t col565, uint16_t id);

//Désactivation de la zone tactile indiquée
void lcdUndefTouch(uint16_t id);

//Définition d'une zone de texte dans le LCD
void lcdDefTextArea(uint16_t xn,uint16_t xm, uint16_t yn, uint16_t ym);

//Trace un rectangle plein dans la couleur indiquée
void lcdRectFull(uint16_t xn,uint16_t xm, uint16_t yn, uint16_t ym, uint16_t col);

//Trace un rectangle dans la couleur indiquée
void lcdRect(uint16_t xn,uint16_t xm, uint16_t yn, uint16_t ym, uint16_t col);

//Autorise le scrolling dans la zone texte
void lcdSetScroll(uint16_t c);

//Permet l'écriture en dehors de la zone texte définie (les positions d'écriture deviennent relatives au LCD entier)
void lcdSetOutWind(uint16_t c);

//Mémorisation de la position courante d'écriture (10 niveaux possibles)
void lcdPushTxtPos(void);

//Récupération de la position d'écriture mémorisée
void lcdPopTxtPos(void);

//fixe la position d'écriture en absolu dans la fenêtre de texte (coordonnées LCD)
void lcdGotoXYa(uint16_t x,uint16_t y);

//Efface tout l'écran
void lcdClearAll(void);

//définit le nombre de pixels vides à placer entre 2 caractères
void lcdSetSpc(uint16_t nb);

//Active ou désactive lemode Incrust.
//En mode incrust, la couleur du fond n'est pas reportée derrière les caractères
void lcdSetIncrust(uint16_t on);



//Affiche une liste de gifs pendant la durée dur (en 1/10s)
//Liste donnée sous la forme "nn1*x1;nn2*x2;nn3; ... nni*xi"
//    nni : Num�ro du gif dans le tableau GIF
//    xi : nombre de répétitions - paramètre otionnel. Si absent : 1 seule fois
// GIFs définis :
//    "3d-fou","3d-oki","3d-oublier","3d-ouf","3d-robot-1","3d-robot-3","3d-robot-5","3d-sueur",
//    "blagueur","fusee1","fusee2","fusee3","grimace","lune1","mdr","robot","robot-2","robot-4","tintin019",
void lcdAffLGif(uint16_t dur, const char *liste);


//===================================================
//Fonctions d'interrogation :
//===================================================

//Demande la largeur du texte transmis, pour la police courante
int16_t lcdGetTextWidth(const char *txt);

//Demande le nombre de pixels du LCD en largeur
int16_t lcdGetPixelWidth(void);

//Demande le nombre de pixels du LCD en hauteur
int16_t lcdGetPixelHeight(void);

//Demande la hauteur de la police courante
int16_t lcdGetPoliceHeight(void);

//Demande nombre de polices définies
int16_t lcdGetNbFont(void);


//Demande nombre de pixels espaces entre caractères
int16_t lcdGetSpc(void);

int16_t lcdGetAbsX(void);
int16_t lcdGetX(void);
int16_t lcdGetAbsY(void);
int16_t lcdGetX(void);

//Lecture état touches tactiles. Renvoie une chaine du type "A" pour touche 0, "B" pour touche 1...
char *lcdGetK(void);

//fixe la position d'écriture en absolu dans la fenêtre graphique
void lcdMoveTo(uint16_t x, uint16_t y);

//trace une ligne jusqu'à la position indiquée dans fenêtre graphique
void lcdLineTo(uint16_t x, uint16_t y);

//trace un pixel dans fenêtre graphique (couleur courante)
void lcdPutPixel(uint16_t x, uint16_t y);

//trace un pixel dans fenêtre graphique dans la couleur indiquée
void lcdPutPixelC(uint16_t x, uint16_t y, uint16_t col565);

//trace un cercle de rayon r dont le centre est la position graphique courante
void lcdCircle(uint16_t r);

//trace un cercle de rayon r dont le centre est (x,y)
void lcdCircleXY(uint16_t x, uint16_t y, uint16_t r);



//Indique la seule tâche autorisée à afficher (id=0 pour toutes)
//Faire lcdTaskAllow(xTaskGetCurrentTaskHandle()) pour autoriser la tâche courante
void lcdTaskAllow(TaskHandle_t id);


#endif
