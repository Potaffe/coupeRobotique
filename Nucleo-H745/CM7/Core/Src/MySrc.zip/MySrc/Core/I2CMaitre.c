/*
 * I2CMaitre.c
 *
 *  Created on: 23 nov. 2016
 *      Author: Md
 */
//#include "stm32f7xx_hal.h"


#if defined STM32F7
#include "stm32f7xx_hal.h"
#elsif defined STM32H7
#include "stm32h7xx_hal.h"
#elsif defined STM32F4
#include "stm32f4xx_hal.h"
#elsif defined STM32L4
#include "stm32l4xx_hal.h"
#elsif defined STM32G4
#include "stm32g4xx_hal.h"
#endif


#include "i2c.h"
#include "I2CMaitre.h"

#define CxReq 1

uint16_t I2CPing(uint8_t ad)
{
	return 0; //HAL_I2C_IsDeviceReady(&hi2c1,ad<<1,2,2)==HAL_OK;
}

uint16_t I2CWriteByte(uint8_t ad, uint8_t b)
{
	return 0; //HAL_I2C_Master_Transmit(&hi2c1,ad<<1,&b,1,2);
}



uint16_t I2CWriteBytes(uint8_t ad, uint8_t *b, uint16_t nb)
{
	return 0;// HAL_I2C_Master_Transmit(&hi2c1,ad<<1,b,nb,2);
}

static union
{
	uint16_t w;
	struct
	{
		uint8_t cmd,req;
	}b;
}adx={.b={.req=CxReq}};


int16_t I2CReadByte(uint8_t ad, uint8_t cmde)
{
    HAL_StatusTypeDef err=HAL_OK;
    uint8_t rep;
    adx.b.cmd=cmde;
//    err=HAL_I2C_Mem_Read(&hi2c1,ad<<1,adx.w,2,&rep,1,2);
    if(err!=HAL_OK) return -err;
    return rep;
}

int16_t I2CReadBytes(uint8_t ad, uint8_t cmde, uint8_t *data, uint16_t nb)
{
    adx.b.cmd=cmde;
    return 0; //HAL_I2C_Mem_Read(&hi2c1,ad<<1,adx.w,2,data,nb,5);
}




