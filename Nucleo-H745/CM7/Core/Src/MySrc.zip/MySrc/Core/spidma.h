/*
 * spidma.h
 *
 *  Created on: Jun 9, 2016
 *      Author: Md
 */

#ifndef SPIDMA_H_
#define SPIDMA_H_

void SendSpi(void);
void InitSpiDma(void);

//extern int16_t SPIBuf[10];

//#define THETA SPIBuf[0]
//#define P_X SPIBuf[1]
//#define P_Y SPIBuf[2]

#endif /* SPIDMA_H_ */
