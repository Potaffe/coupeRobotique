/*
 * LowLevel.h
 *
 *  Created on: May 27, 2016
 *      Author: Md
 */

#ifndef LOWLEVEL_H_
#define LOWLEVEL_H_


extern volatile uint16_t VBAT;

unsigned VitMotG(int16_t v);
unsigned VitMotD(int16_t v);
unsigned VitMotX(int16_t v);


void SetVitMotG(int16_t v);
void SetVitMotD(int16_t v);
void SetVitMotX(int16_t v);
void SetVitMotGD(int16_t vg, int16_t vd);




void VitTurbine(float pourcent);

void Powen(int16_t st);
void PowTurbine(int16_t st);

int GetDetect(void);


void _LED_ROUGE_ON(uint16_t ms);
void _LED_VERTE_ON(uint16_t ms);
void _LED_ORANGE_ON(uint16_t ms);
void _LED_BLEUE_ON(uint16_t ms);


#endif /* LOWLEVEL_H_ */
