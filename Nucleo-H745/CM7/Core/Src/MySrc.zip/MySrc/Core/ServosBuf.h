/*
 * ServosBuf.h
 *
 *  Created on: Jun 14, 2019
 *      Author: deloi
 */

#ifndef SERVOSBUF_H_
#define SERVOSBUF_H_

void HuartRX_TxCpltCallback(void);
void HuartRX_RxCpltCallback(void);
void HuartAX_TxCpltCallback(void);
void HuartAX_RxCpltCallback(void);



#endif /* SERVOSBUF_H_ */
