/*
 * MotX.h
 *
 *  Created on: 16 juin 2019
 *      Author: deloi
 */

#ifndef MOTX_H_
#define MOTX_H_

void StartXPos(int n);
void MoveXPos(int n);
void CalageBarillet(void);



#endif /* MOTX_H_ */
